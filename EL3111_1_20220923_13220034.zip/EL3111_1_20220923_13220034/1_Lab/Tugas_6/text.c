// Praktikum EL3111 Arsitektur Sistem Komputer
// Modul : 1
// Percobaan : 6
// Tanggal : 23 September 2022
// Kelompok : 10
// Rombongan : B
// Nama (NIM) 1 : Ahmad Aziz (13220034)
// Nama (NIM) 2 : Gilbert Ng (13220032)
// Nama File : text.c
// Deskripsi : Demonstrasi MakeFile, Mencetak string ke layar
#include <stdio.h>
#include "text.h"
void test(void){
    printf("Arsitektur Sistem Komputer sangat menyenangkan!\n");
}
