// Praktikum EL3111 Arsitektur Sistem Komputer
// Modul : 1
// Percobaan : 5
// Tanggal : 23 September 2022
// Kelompok : 10
// Rombongan : B
// Nama (NIM) 1 : Ahmad Aziz (13220034)
// Nama (NIM) 2 : Gilbert Ng (13220032)
// Nama File : main_text.c
// Deskripsi : Demonstrasi MakeFile
// Memanggil prosedur test pada text.c
#include "text.h"
void main(void){
    test();
}
