// Praktikum EL3111 Arsitektur Sistem Komputer
// Modul : 1
// Percobaan : 5
// Tanggal : 23 September 2022
// Kelompok : 10
// Rombongan : B
// Nama (NIM) 1 : Ahmad Aziz (13220034)
// Nama (NIM) 2 : Gilbert Ng (13220032)
// Nama File : text.h
// Deskripsi : Demonstrasi MakeFile, Mencetak string ke layar
#ifndef TES_H
    #define TES_H 100
    void test(void);
#endif