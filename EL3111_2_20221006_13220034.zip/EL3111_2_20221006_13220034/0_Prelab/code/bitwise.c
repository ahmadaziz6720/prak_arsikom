#include <stdio.h>

int main(){
    short int a = 2022;

    printf("a = %d\n", (a << 5)>>2);

    return 0;
}